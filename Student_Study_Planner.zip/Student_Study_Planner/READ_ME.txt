1. Open XAMPP on your Desktop
2. Start the Apache and MySQL server
3. Click on the Admin button of MySQL 
4. On the phpMyAdmin interface click  Import and choose the "student_study_planner.sql". Then click Impor at the bottom
5. Copy the study_planner and paste it into htdocs of the XAMPP folder
6. Open brower and type  localhost/student_study_planner/
7. Press enter
8. navigate the app
